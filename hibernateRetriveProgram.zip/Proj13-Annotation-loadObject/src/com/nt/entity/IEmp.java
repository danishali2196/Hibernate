package com.nt.entity;

public interface IEmp {

	
	public int getEid() ;
	public void setEid(int eid) ;
	public String getEname();
	public void setEname(String ename) ;
	public String getDesg() ;
	public void setDesg(String desg) ;
	public float getSalary();
	public void setSalary(float salary);

}
